# Jujutsu Craft SMP — Fabric 1.21 starter project

This is a starter implementation for Minecraft Java 1.21. It is source code, not a precompiled/verified JAR.

## Features in this starter
- Craftable Lucky Jujutsu Block; right-click consumes it and gives one random jujutsu.
- Eight custom jujutsu items.
- `/menu` lists the jujutsu items.
- `/jujutsu recipe` prints the Lucky Jujutsu Block recipe.
- Basic abilities and individual cooldowns.
- Placeholder 16x16 item textures are included; replace them with your own art.

## Build on Android with Termux
1. Install Termux from its official source: https://github.com/termux/termux-app
2. Install Java 21 and Gradle:
   `pkg update && pkg upgrade`
   `pkg install openjdk-21 gradle git unzip`
3. Extract this project into Termux's private home directory, for example `~/JujutsuCraftSmp`.
4. Run:
   `cd ~/JujutsuCraftSmp`
   `gradle build`
5. If the build succeeds, the JAR is in `build/libs/`. Copy the main JAR (not `-sources.jar`) to the `mods` folder used by your PojavLauncher Fabric 1.21 profile.
6. Install Fabric API 0.102.0+1.21 in the same `mods` folder.

## Controls
- Lucky Jujutsu Block: right-click to consume and receive a random jujutsu.
- Rasengen / Chidori: right-click to use.
- Flying Rijin: crouch + right-click to mark your current location; right-click to teleport to the saved mark.
- Sage Mode, Genjustsu, Shadow Clone, Reanimation, Fire Ball: crouch + right-click.
- Reanimation is intentionally a safe placeholder: it heals nearby players; it does not bypass server bans or moderation.
- `/menu` lists items; `/jujutsu recipe` shows the lucky-block recipe.

## Important limitations
This is a first playable prototype, not a finished competitive SMP mod. Shadow clones are represented by temporary decoys rather than fully AI-controlled copies. Genjustsu uses a short slowness effect rather than hard-freezing every action. The Flying Rijin prototype stores one mark per player, and the menu is chat-based. The Fire Ball ability temporarily changes a 5x5 ground patch to lava and restores original blocks after 10 seconds; test on a backup world first.
