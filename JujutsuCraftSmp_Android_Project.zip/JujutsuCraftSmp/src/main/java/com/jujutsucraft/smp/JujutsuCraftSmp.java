package com.jujutsucraft.smp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import com.mojang.brigadier.Command;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static net.minecraft.server.command.CommandManager.literal;

public class JujutsuCraftSmp implements ModInitializer {
    public static final String MOD_ID = "jujutsu_craft_smp";

    public static Item LUCKY_BLOCK;
    public static Item RASENGEN;
    public static Item CHIDORI;
    public static Item FLYING_RIJIN;
    public static Item SAGE_MODE;
    public static Item GENJUSTSU;
    public static Item SHADOW_CLONE;
    public static Item REANIMATION;
    public static Item FIRE_BALL;

    private static final List<Item> JUJUTSUS = new ArrayList<>();
    private static final Map<UUID, Long> COOLDOWNS = new ConcurrentHashMap<>();
    private static final Map<UUID, BlockPos> MARKS = new ConcurrentHashMap<>();
    private static final List<TemporaryBlock> TEMP_BLOCKS = new ArrayList<>();
    private static final Random RANDOM = new Random();

    private record TemporaryBlock(ServerWorld world, BlockPos pos, net.minecraft.block.BlockState original, long restoreAt) {}

    private static Item register(String name) {
        Item item = new Item(new Item.Settings().maxCount(1));
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, name), item);
    }

    @Override
    public void onInitialize() {
        LUCKY_BLOCK = register("lucky_jujutsu_block");
        RASENGEN = register("rasengen");
        CHIDORI = register("chidori");
        FLYING_RIJIN = register("flying_rijin");
        SAGE_MODE = register("sage_mode");
        GENJUSTSU = register("genjustsu");
        SHADOW_CLONE = register("shadow_clone");
        REANIMATION = register("reanimation");
        FIRE_BALL = register("fire_ball");
        JUJUTSUS.addAll(List.of(RASENGEN, CHIDORI, FLYING_RIJIN, SAGE_MODE, GENJUSTSU, SHADOW_CLONE, REANIMATION, FIRE_BALL));

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            Item item = stack.getItem();
            if (world.isClient) return ActionResult.PASS;

            if (item == LUCKY_BLOCK) {
                stack.decrement(1);
                Item reward = JUJUTSUS.get(RANDOM.nextInt(JUJUTSUS.size()));
                player.getInventory().insertStack(new ItemStack(reward));
                player.sendMessage(Text.literal("Lucky Jujutsu Block became: " + displayName(reward)), false);
                return ActionResult.SUCCESS;
            }

            if (!JUJUTSUS.contains(item)) return ActionResult.PASS;
            if (item == FLYING_RIJIN) {
                if (player.isSneaking()) {
                    MARKS.put(player.getUuid(), player.getBlockPos().toImmutable());
                    player.sendMessage(Text.literal("Flying Rijin: location marked."), false);
                } else {
                    BlockPos mark = MARKS.get(player.getUuid());
                    if (mark == null) {
                        player.sendMessage(Text.literal("No mark saved. Crouch + right-click to mark a location."), false);
                    } else {
                        player.teleport(mark.getX() + 0.5, mark.getY() + 1, mark.getZ() + 0.5);
                        if (!cooldownReady(player, item, 300)) return ActionResult.SUCCESS;
                        setCooldown(player, item, 300);
                    }
                }
                return ActionResult.SUCCESS;
            }

            boolean needsSneak = item != RASENGEN && item != CHIDORI;
            if (needsSneak && !player.isSneaking()) {
                player.sendMessage(Text.literal("Crouch + right-click to use " + displayName(item) + "."), false);
                return ActionResult.SUCCESS;
            }

            int cooldown = cooldownSeconds(item);
            if (!cooldownReady(player, item, cooldown)) return ActionResult.SUCCESS;
            setCooldown(player, item, cooldown);

            if (item == RASENGEN) {
                damageTarget(player, 4.0f);
                player.sendMessage(Text.literal("Rasengen!"), true);
            } else if (item == CHIDORI) {
                damageTarget(player, 3.0f);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 50, 1));
                player.sendMessage(Text.literal("Chidori!"), true);
            } else if (item == SAGE_MODE) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1200, 1));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200, 0));
                player.sendMessage(Text.literal("Sage Mode activated!"), true);
            } else if (item == GENJUSTSU) {
                Entity target = getTarget(player, 12);
                if (target instanceof net.minecraft.entity.LivingEntity living && target != player) {
                    living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 300, 10));
                    living.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 300, 128));
                    player.sendMessage(Text.literal("Genjustsu hit!"), true);
                } else player.sendMessage(Text.literal("Aim at a nearby target."), false);
            } else if (item == SHADOW_CLONE) {
                if (player.getWorld() instanceof ServerWorld sw) {
                    for (int i = 0; i < 5; i++) {
                        ArmorStandEntity decoy = new ArmorStandEntity(EntityType.ARMOR_STAND, sw);
                        double angle = (Math.PI * 2 * i) / 5;
                        decoy.refreshPositionAndAngles(player.getX() + Math.cos(angle) * 1.8, player.getY(), player.getZ() + Math.sin(angle) * 1.8, player.getYaw(), 0);
                        decoy.setCustomName(Text.literal("Shadow Clone"));
                        decoy.setCustomNameVisible(true);
                        decoy.setNoGravity(true);
                        sw.spawnEntity(decoy);
                    }
                    player.sendMessage(Text.literal("Five shadow decoys summoned briefly (prototype)."), true);
                }
            } else if (item == REANIMATION) {
                player.heal(6.0f);
                player.sendMessage(Text.literal("Reanimation prototype: restored your health. Server bans are not bypassed."), false);
            } else if (item == FIRE_BALL) {
                makeTemporaryLava(player);
                player.sendMessage(Text.literal("Fire Ball! Temporary 5x5 lava field."), true);
            }
            return ActionResult.SUCCESS;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("menu").executes(ctx -> {
                ctx.getSource().sendFeedback(() -> Text.literal("Jujutsu available: Rasengen, Chidori, Flying Rijin, Sage Mode, Genjustsu, Shadow Clone, Reanimation, Fire Ball."), false);
                ctx.getSource().sendFeedback(() -> Text.literal("Craft a Lucky Jujutsu Block, then right-click it for a random jujutsu."), false);
                return Command.SINGLE_SUCCESS;
            }));
            dispatcher.register(literal("jujutsu").then(literal("recipe").executes(ctx -> {
                ctx.getSource().sendFeedback(() -> Text.literal("Lucky Jujutsu Block recipe (shaped): Ender Pearl | Gold Ingot | Ender Pearl; Gold Ingot | Diamond | Gold Ingot; Ender Pearl | Gold Ingot | Ender Pearl."), false);
                return Command.SINGLE_SUCCESS;
            })));
        });

        ServerTickEvents.END_SERVER_TICK.register(JujutsuCraftSmp::tickTemporaryBlocks);
    }

    private static String displayName(Item item) {
        String id = Registries.ITEM.getId(item).getPath().replace('_', ' ');
        String[] parts = id.split(" ");
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (!p.isEmpty()) b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        }
        return b.toString().trim();
    }

    private static String cooldownKey(Item item) { return Registries.ITEM.getId(item).toString(); }
    private static boolean cooldownReady(PlayerEntity player, Item item, int seconds) {
        long now = player.getWorld().getTime();
        String key = player.getUuid() + ":" + cooldownKey(item);
        long ready = COOLDOWNS.getOrDefault(UUID.nameUUIDFromBytes(key.getBytes()), 0L);
        if (now < ready) {
            player.sendMessage(Text.literal("Cooldown: " + Math.max(1, (ready - now) / 20) + " seconds."), true);
            return false;
        }
        return true;
    }
    private static void setCooldown(PlayerEntity player, Item item, int seconds) {
        String key = player.getUuid() + ":" + cooldownKey(item);
        COOLDOWNS.put(UUID.nameUUIDFromBytes(key.getBytes()), player.getWorld().getTime() + seconds * 20L);
    }
    private static int cooldownSeconds(Item item) {
        if (item == RASENGEN) return 180;
        if (item == CHIDORI) return 60;
        if (item == SAGE_MODE) return 120;
        if (item == GENJUSTSU) return 120;
        if (item == SHADOW_CLONE) return 180;
        if (item == FIRE_BALL) return 60;
        return 300;
    }
    private static Entity getTarget(PlayerEntity player, double range) {
        Vec3d start = player.getCameraPosVec(1.0f);
        Vec3d end = start.add(player.getRotationVec(1.0f).multiply(range));
        return player.getWorld().getOtherEntities(player, player.getBoundingBox().stretch(end.subtract(start)).expand(1.0),
                e -> e instanceof net.minecraft.entity.LivingEntity && e.squaredDistanceTo(player) <= range * range)
                .stream().min(Comparator.comparingDouble(e -> e.squaredDistanceTo(player))).orElse(null);
    }
    private static void damageTarget(PlayerEntity player, float damage) {
        Entity target = getTarget(player, 3.5);
        if (target instanceof net.minecraft.entity.LivingEntity living && target != player) {
            living.damage(player.getDamageSources().playerAttack(player), damage);
        } else {
            player.sendMessage(Text.literal("Move close to an opponent and aim at them."), false);
        }
    }
    private static void makeTemporaryLava(PlayerEntity player) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        Vec3d look = player.getRotationVec(1.0f);
        BlockPos center = BlockPos.ofFloored(player.getX() + look.x * 4, player.getY() + look.y * 4, player.getZ() + look.z * 4);
        BlockPos ground = world.getTopPosition(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, center);
        long restoreAt = world.getTime() + 200;
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
            BlockPos pos = ground.add(x, -1, z);
            if (world.getBlockState(pos).isAir() || world.getBlockState(pos).getBlock() == Blocks.LAVA || world.getBlockState(pos).getBlock() == Blocks.BEDROCK) continue;
            BlockPos lavaPos = pos.up();
            if (!world.getBlockState(lavaPos).isAir()) continue;
            TEMP_BLOCKS.add(new TemporaryBlock(world, lavaPos.toImmutable(), world.getBlockState(lavaPos), restoreAt));
            world.setBlockState(lavaPos, Blocks.LAVA.getDefaultState(), 3);
        }
    }
    private static void tickTemporaryBlocks(MinecraftServer server) {
        Iterator<TemporaryBlock> it = TEMP_BLOCKS.iterator();
        while (it.hasNext()) {
            TemporaryBlock temp = it.next();
            if (temp.world().getTime() >= temp.restoreAt()) {
                if (temp.world().getBlockState(temp.pos()).getBlock() == Blocks.LAVA) {
                    temp.world().setBlockState(temp.pos(), temp.original(), 3);
                }
                it.remove();
            }
        }
    }

}
